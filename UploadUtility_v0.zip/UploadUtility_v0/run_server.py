import uvicorn
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

# Paths to your certificate and key (generate once)
CERT_FILE = BASE_DIR / "cert.pem"
KEY_FILE = BASE_DIR / "key.pem"

uvicorn.run(
    "app:app",
    host="0.0.0.0",
    port=8000,
    reload=False,
    ssl_certfile=str(CERT_FILE),
    ssl_keyfile=str(KEY_FILE)
)
