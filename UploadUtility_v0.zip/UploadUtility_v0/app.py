from fastapi import FastAPI, UploadFile, File, Form, Request
from fastapi.responses import HTMLResponse, FileResponse
from pathlib import Path
import shutil
from datetime import datetime

app = FastAPI()

BASE_DIR = Path(__file__).resolve().parent
UPLOAD_DIR = BASE_DIR / "uploads"
UPLOAD_DIR.mkdir(exist_ok=True)

LOG_FILE = BASE_DIR / "upload_log.txt"

@app.get("/", response_class=HTMLResponse)
def index():
    return """
    <html>
        <head>
            <style>
                body { font-family: 'Courier New', Courier, monospace; }
                h3, text, input, button { font-family: inherit; }
            </style>
        </head>
        <body>
            <h3>Upload your zip</h3>
            <text>Please enter your ID and choose your file to upload</text>
            <br><br>
            <form action="/upload" method="post" enctype="multipart/form-data">
                Student ID: <input type="text" name="student_id" required>
                <br><br>
                File: <input type="file" name="file" required>
                <br><br>
                <button type="submit">Upload</button>
            </form>
        </body>
    </html>
    """

# Ignore favicon requests
@app.get("/favicon.ico")
def favicon():
    return None  # No content

@app.post("/upload")
def upload(file: UploadFile = File(...), student_id: str = Form(...)):
    # Create student folder
    student_folder = UPLOAD_DIR / student_id
    student_folder.mkdir(exist_ok=True)

    # Save uploaded file
    dest = student_folder / file.filename
    with open(dest, "wb") as f:
        shutil.copyfileobj(file.file, f)

    # Append log entry
    with open(LOG_FILE, "a") as log:
        log.write(f"{datetime.now().isoformat()} | {student_id} | {file.filename}\n")

    return {
        "STATUS": "SUCCESS",
        "STUDENT_ID": student_id,
        "FILENAME": file.filename
    }
