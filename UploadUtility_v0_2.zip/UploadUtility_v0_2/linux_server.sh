#!/usr/bin/env bash
set -euo pipefail

# -------- logging --------
LOGFILE="$HOME/upload_utility.log"
exec > >(tee -a "$LOGFILE") 2>&1

echo "=== Script started at $(date) ==="

# -------- ensure correct directory --------
cd "$HOME/Desktop/UploadUtility_v0_2"

# -------- live ISO safety: disable cdrom repo if present --------
echo "Checking for CD-ROM APT sources..."
if grep -q '^deb cdrom:' /etc/apt/sources.list 2>/dev/null; then
    echo "Disabling CD-ROM repository (live environment detected)"
    sudo sed -i 's|^deb cdrom:|# deb cdrom:|g' /etc/apt/sources.list
fi

# -------- update system --------
echo "Updating package lists..."
sudo apt update

# -------- ensure venv support --------
echo "Ensuring python3.12-venv is installed..."
sudo apt install -y python3.12-venv

# -------- create venv only if missing --------
if [ ! -d venv ]; then
    echo "Creating virtual environment..."
    python3.12 -m venv venv
else
    echo "Virtual environment already exists"
fi

# -------- activate venv --------
echo "Activating virtual environment..."
source venv/bin/activate

# -------- install dependencies --------
echo "Installing Python dependencies..."
python -m pip install --upgrade pip
python -m pip install -r requirements.txt

# -------- low-port binding capability --------
echo "Checking network bind capability..."
if ! getcap /usr/bin/python3.12 | grep -q cap_net_bind_service; then
    echo "Applying cap_net_bind_service to python3.12 (sudo required)"
    sudo setcap 'cap_net_bind_service=+ep' /usr/bin/python3.12
else
    echo "cap_net_bind_service already set"
fi

# -------- run server --------
echo "Starting server..."
python -m run_server

