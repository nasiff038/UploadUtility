import uvicorn
from pathlib import Path

def main():

    # BASE_DIR = Path(__file__).resolve().parent
    # CERT_FILE = BASE_DIR / "cert.pem"
    # KEY_FILE = BASE_DIR / "key.pem"  
    
    uvicorn.run(
        "app:app",
        host="0.0.0.0",
        port=80,
        reload=False
    )
    
    
if __name__ == "__main__":
    main()