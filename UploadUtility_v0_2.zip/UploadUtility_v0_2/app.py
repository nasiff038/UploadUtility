from fastapi import FastAPI, UploadFile, File, Form, Request, HTTPException
from fastapi.responses import HTMLResponse, FileResponse
from pathlib import Path
import shutil
from datetime import datetime
import logging
import re

app = FastAPI()

STUDENT_ID_PATTERN = re.compile(r"^\d{7}$")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    handlers=[
        logging.FileHandler("upload_log.txt"),
        logging.StreamHandler()  # prints to console
    ]
)

BASE_DIR = Path(__file__).resolve().parent
UPLOAD_DIR = BASE_DIR / "uploads"
UPLOAD_DIR.mkdir(exist_ok=True)

LOG_FILE = BASE_DIR / "upload_log.txt"

@app.get("/", response_class=HTMLResponse)
def index():
    
    logging.info("GET / requested")
    with open('index.html', 'r', encoding='utf-8') as f:
        return f.read()

# Ignore favicon requests
@app.get("/favicon.ico")
def favicon():
    return None  # No content

@app.post("/upload")
def upload(file: UploadFile = File(...), student_id: str = Form(...)):

    # Sanity check student ID input
    if not STUDENT_ID_PATTERN.fullmatch(student_id):
        logging.warning(f"Invalid Student ID attempt: {student_id}")
        raise HTTPException(
            status_code=400,
            detail=f"Invalid Student ID: {student_id}. Expected format: YYDDNNN (7 digits)."
        )
    

    # Create student folder
    student_folder = UPLOAD_DIR / student_id
    student_folder.mkdir(exist_ok=True)

    # Save uploaded file
    dest = student_folder / file.filename
    with open(dest, "wb") as f:
        shutil.copyfileobj(file.file, f)

    # Append log entry
    with open(LOG_FILE, "a") as log:
        log.write(f"CONNECT: {datetime.now().isoformat()} | {student_id} | {file.filename}\n")
    # also create a terminal log
    logging.info(f"{student_id} uploaded {file.filename}")

    return {
        "STATUS": "SUCCESS",
        "STUDENT_ID": student_id,
        "FILENAME": file.filename
    }

@app.get("/ping")
def ping():
    return {'status': 'ONLINE'}
